const express = require('express');
const router = express.Router();
const authController = require('../controllers/authController');
const { verifyAdminToken } = require('../middleware/authMiddleware');
// Admin Login & Token Verification
router.post('/login', authController.loginAdmin);
router.get('/verify', verifyAdminToken, authController.verifyToken);
module.exports = router;
