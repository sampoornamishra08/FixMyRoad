const express = require('express');
const router = express.Router();
const reportController = require('../controllers/reportController');
const { validateReportInput } = require('../middleware/validateMiddleware');
const { verifyAdminToken } = require('../middleware/authMiddleware');
// Public Citizen Endpoints
router.get('/', reportController.getReports);
router.get('/:id', reportController.getReportById);
router.post('/', validateReportInput, reportController.createReport);
// Protected Admin Endpoints
router.patch('/:id/rectify', verifyAdminToken, reportController.markRectified);
router.patch('/:id/status', verifyAdminToken, reportController.updateStatus);
module.exports = router;
