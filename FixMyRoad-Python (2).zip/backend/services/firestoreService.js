const demoReportsData = require('../data/demoReports.json');
const { isFirebaseReady, db } = require('../config/firebase');
const { SLA_OVERDUE_DAYS } = require('../config/constants');
// In-Memory storage initialized with realistic demo data
let inMemoryReports = JSON.parse(JSON.stringify(demoReportsData));
/**
 * Dynamically computes real-time age and 90-day SLA flags
 */
function enrichReport(report) {
  const createdTime = new Date(report.createdAt).getTime();
  const now = Date.now();
  const diffMs = Math.max(0, now - createdTime);
  const daysUnresolved = Math.floor(diffMs / (1000 * 60 * 60 * 24));
  const isOverdue90Days = report.status !== 'Rectified' && daysUnresolved >= SLA_OVERDUE_DAYS;
  let ageDisplay = 'Today';
  if (daysUnresolved === 1) ageDisplay = '1 day ago';
  else if (daysUnresolved > 1) ageDisplay = `${daysUnresolved} days ago`;
  return {
    ...report,
    daysUnresolved,
    isOverdue90Days,
    ageDisplay
  };
}
async function getAllReports(filter = {}) {
  let reports = [];
  if (isFirebaseReady && db) {
    try {
      const snapshot = await db.collection('reports').orderBy('createdAt', 'desc').get();
      snapshot.forEach(doc => reports.push({ id: doc.id, ...doc.data() }));
    } catch (e) {
      console.warn('Firestore fetch failed, using local memory fallback:', e.message);
      reports = inMemoryReports;
    }
  } else {
    reports = inMemoryReports;
  }
  // Enrich with dynamic 90-day age calculations
  let enriched = reports.map(enrichReport);
  // Apply filters
  if (filter.status) {
    enriched = enriched.filter(r => r.status.toLowerCase() === filter.status.toLowerCase());
  }
  if (filter.severity) {
    enriched = enriched.filter(r => r.severity.toLowerCase() === filter.severity.toLowerCase());
  }
  if (filter.overdue === 'true' || filter.overdue === true) {
    enriched = enriched.filter(r => r.isOverdue90Days);
  }
  // Sort: Overdue & Critical first, then newest
  enriched.sort((a, b) => {
    if (a.isOverdue90Days && !b.isOverdue90Days) return -1;
    if (!a.isOverdue90Days && b.isOverdue90Days) return 1;
    return new Date(b.createdAt) - new Date(a.createdAt);
  });
  return enriched;
}
async function getReportById(reportId) {
  const reports = await getAllReports();
  const report = reports.find(r => r.reportId === reportId || r.id === reportId);
  return report ? enrichReport(report) : null;
}
async function createReport(reportData) {
  const now = new Date().toISOString();
  const randomSuffix = Math.random().toString(36).substring(2, 6).toUpperCase();
  const reportId = `FMR-${Date.now().toString().slice(-6)}-${randomSuffix}`;
  const newReport = {
    reportId,
    title: reportData.title || `Road Hazard on ${reportData.location?.roadName || 'Reported Location'}`,
    description: reportData.description || 'Pothole reported by citizen.',
    location: {
      latitude: parseFloat(reportData.location.latitude),
      longitude: parseFloat(reportData.location.longitude),
      roadName: reportData.location.roadName || 'Road Location Recorded',
      city: reportData.location.city || 'Bengaluru',
      pincode: reportData.location.pincode || ''
    },
    severity: reportData.severity || 'Medium',
    photoUrl: reportData.photoUrl || '',
    status: 'Pending',
    reportedBy: reportData.reportedBy || 'Citizen (Anonymous)',
    createdAt: now,
    updatedAt: now,
    rectifiedAt: null,
    rectifiedBy: null,
    adminRemarks: '',
    aiMetadata: reportData.aiMetadata || null
  };
  inMemoryReports.unshift(newReport);
  if (isFirebaseReady && db) {
    try {
      await db.collection('reports').doc(reportId).set(newReport);
    } catch (e) {
      console.warn('Firestore write warning:', e.message);
    }
  }
  return enrichReport(newReport);
}
async function markReportRectified(reportId, adminEmail = 'admin@fixmyroad.gov.in', remarks = '') {
  const now = new Date().toISOString();
  let updatedReport = null;
  const index = inMemoryReports.findIndex(r => r.reportId === reportId || r.id === reportId);
  if (index !== -1) {
    inMemoryReports[index].status = 'Rectified';
    inMemoryReports[index].rectifiedAt = now;
    inMemoryReports[index].rectifiedBy = adminEmail;
    inMemoryReports[index].updatedAt = now;
    if (remarks) inMemoryReports[index].adminRemarks = remarks;
    updatedReport = inMemoryReports[index];
  }
  if (isFirebaseReady && db) {
    try {
      await db.collection('reports').doc(reportId).update({
        status: 'Rectified',
        rectifiedAt: now,
        rectifiedBy: adminEmail,
        updatedAt: now,
        adminRemarks: remarks || 'Resolved by road maintenance authority'
      });
    } catch (e) {
      console.warn('Firestore update warning:', e.message);
    }
  }
  return updatedReport ? enrichReport(updatedReport) : null;
}
async function updateReportStatus(reportId, status, remarks = '') {
  const now = new Date().toISOString();
  let updatedReport = null;
  const index = inMemoryReports.findIndex(r => r.reportId === reportId || r.id === reportId);
  if (index !== -1) {
    inMemoryReports[index].status = status;
    inMemoryReports[index].updatedAt = now;
    if (remarks) inMemoryReports[index].adminRemarks = remarks;
    updatedReport = inMemoryReports[index];
  }
  return updatedReport ? enrichReport(updatedReport) : null;
}
async function getStats() {
  const reports = await getAllReports();
  const total = reports.length;
  const pending = reports.filter(r => r.status === 'Pending').length;
  const inProgress = reports.filter(r => r.status === 'In Progress').length;
  const critical = reports.filter(r => r.severity === 'Critical' && r.status !== 'Rectified').length;
  const high = reports.filter(r => r.severity === 'High' && r.status !== 'Rectified').length;
  const overdue90Days = reports.filter(r => r.isOverdue90Days).length;
  const rectified = reports.filter(r => r.status === 'Rectified').length;
  return {
    total,
    pending,
    inProgress,
    critical,
    high,
    overdue90Days,
    rectified,
    resolutionRate: total > 0 ? Math.round((rectified / total) * 100) : 0
  };
}
function resetDemoData() {
  inMemoryReports = JSON.parse(JSON.stringify(demoReportsData));
  return inMemoryReports.map(enrichReport);
}
module.exports = {
  getAllReports,
  getReportById,
  createReport,
  markReportRectified,
  updateReportStatus,
  getStats,
  resetDemoData
};
