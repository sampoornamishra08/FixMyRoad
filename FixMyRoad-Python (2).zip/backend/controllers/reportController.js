const firestoreService = require('../services/firestoreService');
async function getReports(req, res) {
  try {
    const { status, severity, overdue } = req.query;
    const reports = await firestoreService.getAllReports({ status, severity, overdue });
    res.json({
      success: true,
      count: reports.length,
      data: reports
    });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
}
async function getReportById(req, res) {
  try {
    const report = await firestoreService.getReportById(req.params.id);
    if (!report) {
      return res.status(404).json({ success: false, message: 'Report not found' });
    }
    res.json({ success: true, data: report });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
}
async function createReport(req, res) {
  try {
    const newReport = await firestoreService.createReport(req.body);
    res.status(201).json({
      success: true,
      message: 'Pothole report registered successfully.',
      data: newReport
    });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
}
async function markRectified(req, res) {
  try {
    const adminEmail = req.adminUser?.email || 'admin@fixmyroad.gov.in';
    const { remarks } = req.body;
    const updated = await firestoreService.markReportRectified(req.params.id, adminEmail, remarks);
    if (!updated) {
      return res.status(404).json({ success: false, message: 'Report not found to rectify.' });
    }
    res.json({
      success: true,
      message: `Report ${req.params.id} successfully marked as RECTIFIED.`,
      data: updated
    });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
}
async function updateStatus(req, res) {
  try {
    const { status, remarks } = req.body;
    const updated = await firestoreService.updateReportStatus(req.params.id, status, remarks);
    if (!updated) {
      return res.status(404).json({ success: false, message: 'Report not found.' });
    }
    res.json({
      success: true,
      message: `Report status updated to ${status}.`,
      data: updated
    });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
}
async function getStats(req, res) {
  try {
    const stats = await firestoreService.getStats();
    res.json({ success: true, data: stats });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
}
async function seedDemoData(req, res) {
  try {
    const resetList = firestoreService.resetDemoData();
    res.json({
      success: true,
      message: 'Demo dataset reset successfully.',
      count: resetList.length,
      data: resetList
    });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
}
module.exports = {
  getReports,
  getReportById,
  createReport,
  markRectified,
  updateStatus,
  getStats,
  seedDemoData
};
