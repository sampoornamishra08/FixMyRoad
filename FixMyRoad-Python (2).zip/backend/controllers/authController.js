function loginAdmin(req, res) {
  const { userId, password } = req.body;
  const expectedUserId = process.env.ADMIN_USER_ID || 'admin@fixmyroad.gov.in';
  const expectedPassword = process.env.ADMIN_PASSWORD || 'Admin@12345';
  if (!userId || !password) {
    return res.status(400).json({
      success: false,
      message: 'Please provide both User ID / Email and Password.'
    });
  }
  // Secure credential verification
  if (
    (userId.trim().toLowerCase() === expectedUserId.toLowerCase() || userId.trim() === 'admin') &&
    password === expectedPassword
  ) {
    const token = `fmr_admin_jwt_${Buffer.from(userId + ':' + Date.now()).toString('base64')}`;
    
    return res.json({
      success: true,
      message: 'Admin authentication successful.',
      data: {
        token,
        user: {
          email: expectedUserId,
          name: 'Chief Municipal Road Inspector',
          department: 'Public Works Department (PWD)',
          role: 'ADMIN'
        }
      }
    });
  }
  return res.status(401).json({
    success: false,
    message: 'Invalid User ID or Password. Please check credentials.'
  });
}
function verifyToken(req, res) {
  res.json({
    success: true,
    message: 'Token is valid.',
    user: req.adminUser
  });
}
module.exports = {
  loginAdmin,
  verifyToken
};
