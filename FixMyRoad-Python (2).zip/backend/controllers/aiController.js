const aiService = require('../services/aiService');
async function analyzeSeverity(req, res) {
  try {
    const { imageBase64, description } = req.body;
    const result = await aiService.analyzePotholeImage(imageBase64);
    res.json({
      success: true,
      data: result
    });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
}
async function checkDuplicate(req, res) {
  try {
    const { latitude, longitude } = req.body;
    if (latitude === undefined || longitude === undefined) {
      return res.status(400).json({
        success: false,
        message: 'Latitude and Longitude are required for duplicate check.'
      });
    }
    const result = await aiService.checkNearbyDuplicates(
      parseFloat(latitude),
      parseFloat(longitude)
    );
    res.json({
      success: true,
      data: result
    });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
}
module.exports = {
  analyzeSeverity,
  checkDuplicate
};
