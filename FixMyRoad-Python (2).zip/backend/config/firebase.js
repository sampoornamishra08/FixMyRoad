/**
 * Firebase Admin SDK initialization with safe In-Memory Fallback
 * Guarantees zero crashing during offline / hackathon demos
 */
let db = null;
let isFirebaseReady = false;
try {
  if (process.env.FIREBASE_PROJECT_ID && process.env.FIREBASE_PRIVATE_KEY) {
    const admin = require('firebase-admin');
    admin.initializeApp({
      credential: admin.credential.cert({
        projectId: process.env.FIREBASE_PROJECT_ID,
        clientEmail: process.env.FIREBASE_CLIENT_EMAIL,
        privateKey: process.env.FIREBASE_PRIVATE_KEY.replace(/\\n/g, '\n')
      })
    });
    db = admin.firestore();
    isFirebaseReady = true;
    console.log('✅ Connected to Cloud Firestore.');
  } else {
    console.log('ℹ️ Firebase credentials not provided. Using high-performance In-Memory Datastore.');
  }
} catch (error) {
  console.warn('⚠️ Firebase init warning (continuing with In-Memory store):', error.message);
}
module.exports = {
  db,
  isFirebaseReady
};
