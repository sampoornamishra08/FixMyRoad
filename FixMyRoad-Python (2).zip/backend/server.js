require('dotenv').config();
const express = require('express');
const path = require('path');
const cors = require('cors');
const reportRoutes = require('./routes/reportRoutes');
const authRoutes = require('./routes/authRoutes');
const aiRoutes = require('./routes/aiRoutes');
const { getStats, seedDemoData } = require('./controllers/reportController');
const app = express();
const PORT = process.env.PORT || 5000;
// Middleware
app.use(cors());
app.use(express.json({ limit: '15mb' }));
app.use(express.urlencoded({ extended: true, limit: '15mb' }));
// Serve Static Frontend Assets
app.use(express.static(path.join(__dirname, '../frontend')));
// API Routes
app.use('/api/reports', reportRoutes);
app.use('/api/auth', authRoutes);
app.use('/api/ai', aiRoutes);
app.get('/api/stats', getStats);
app.post('/api/seed-demo', seedDemoData);
// Health Check Endpoint
app.get('/api/health', (req, res) => {
  res.json({
    status: 'online',
    service: 'FixMyRoad API',
    uptime: process.uptime(),
    timestamp: new Date().toISOString()
  });
});
// Root Redirection
app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, '../frontend/index.html'));
});
// 404 Handler
app.use((req, res) => {
  res.status(404).json({ success: false, message: 'Resource not found' });
});
// Global Error handler
app.use((err, req, res, next) => {
  console.error('Server Internal Error:', err);
  res.status(500).json({
    success: false,
    message: 'Internal server error occurred.',
    error: process.env.NODE_ENV === 'development' ? err.message : undefined
  });
});
// Start Server
app.listen(PORT, () => {
  console.log(`=================================================`);
  console.log(`🚀 FixMyRoad Server is actively running!`);
  console.log(`🌐 Web App:  http://localhost:${PORT}`);
  console.log(`🔌 API:      http://localhost:${PORT}/api/health`);
  console.log(`📊 Reports:  http://localhost:${PORT}/api/reports`);
  console.log(`=================================================`);
});
