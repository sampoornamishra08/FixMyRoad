const { SEVERITY_LEVELS } = require('../config/constants');
function validateReportInput(req, res, next) {
  const { location, severity } = req.body;
  if (!location || location.latitude === undefined || location.longitude === undefined) {
    return res.status(400).json({
      success: false,
      message: 'Validation Error: Latitude and Longitude are required for reporting a pothole.'
    });
  }
  const lat = parseFloat(location.latitude);
  const lng = parseFloat(location.longitude);
  if (isNaN(lat) || lat < -90 || lat > 90 || isNaN(lng) || lng < -180 || lng > 180) {
    return res.status(400).json({
      success: false,
      message: 'Validation Error: Coordinates must be valid geographic values.'
    });
  }
  const validSeverities = Object.values(SEVERITY_LEVELS);
  if (severity && !validSeverities.includes(severity)) {
    return res.status(400).json({
      success: false,
      message: `Validation Error: Severity must be one of: ${validSeverities.join(', ')}`
    });
  }
  next();
}
module.exports = {
  validateReportInput
};
